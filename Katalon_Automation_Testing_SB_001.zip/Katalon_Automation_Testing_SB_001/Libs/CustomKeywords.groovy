
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */



def static "com.qa.amazon.customfunctions.printHello"() {
    (new com.qa.amazon.customfunctions()).printHello()
}
