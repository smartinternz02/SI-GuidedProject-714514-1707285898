import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.amazon.in/')

WebUI.click(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Online Shopping site in India Shop Onl_10c5f3/span_Account  Lists'))

WebUI.setText(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Amazon Sign In/input_email'), 'nikhilanagandula846@gmail.com')

WebUI.click(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Amazon Sign In/inputcontinue'))

WebUI.setEncryptedText(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Amazon Sign In/input_password'), 'aA01fTvnMA2KajHSJqfP6w==')

WebUI.click(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Amazon Sign In/inputsignInSubmit'))

WebUI.setText(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Online Shopping site in India Shop Onl_10c5f3/input_field-keywords'), 
    'laptops')

WebUI.click(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Online Shopping site in India Shop Onl_10c5f3/inputnav-search-submit-button'))

WebUI.click(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Amazon.in  laptops/h2_Dell 15 Laptop, Intel Core i5-1135G7 Pro_fc506b'))

WebUI.click(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Amazon.in  laptops/button_Add to cart'))

WebUI.click(findTestObject('Object Repository/Amazon_pages_OR 5/Page_Amazon.in  laptops/span_Cart'))

WebUI.closeBrowser()

