<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon Test Data testsuite Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>88b0eff3-bf6a-4438-8476-61dedc436c4b</testSuiteGuid>
   <testCaseLink>
      <guid>7715c623-bf62-450b-981c-2f0083c99182</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <iterationNameVariable>
         <defaultValue>''</defaultValue>
         <description></description>
         <id>7b827062-bc31-4630-88d7-d98952fd368a</id>
         <masked>false</masked>
         <name>username</name>
      </iterationNameVariable>
      <testCaseId>Test Cases/DataDrivenTesting/TC_Amazon_Sign_In_DataDriven</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>2dbac077-d26a-4591-81a0-8d7544ac0e69</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon Test Data Excel</testDataId>
      </testDataLink>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>dda567d1-d4d5-4f65-9e93-1ada82baddf5</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon Test Data Excel</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>2dbac077-d26a-4591-81a0-8d7544ac0e69</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>user name</value>
         <variableId>7b827062-bc31-4630-88d7-d98952fd368a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>2dbac077-d26a-4591-81a0-8d7544ac0e69</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>cf55c7c3-31c0-405a-a660-4f641b25b963</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
